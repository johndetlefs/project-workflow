"""Authoritative project-workflow package version."""

__version__ = "0.6.0"
